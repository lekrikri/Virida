# Export Gitea Virida - Mon Aug 25 16:16:45 CEST 2025

## Contenu de cet export

### Repositories
- `repositories/` : Tous les dépôts Git clonés avec historique complet
- `metadata/` : Métadonnées JSON de chaque repository

### Issues
- `issues/` : Toutes les issues exportées par repository (format JSON)

### Organizations
- `organizations/` : Informations sur les organisations (format JSON)

## Statistiques
- Date export: Mon Aug 25 16:16:45 CEST 2025
- Utilisateur: lekrikri
- URL Gitea: https://gitea.com
- Repositories: 2 dépôts
- Issues: 4 fichiers

## Instructions pour ton collègue

### 1. Restaurer les repositories
```bash
# Pour chaque repo dans repositories/
cd repositories/repo-name
git remote set-url origin <nouvelle-url-clever-cloud>
git push --all origin
git push --tags origin
```

### 2. Importer les issues
Les issues sont en format JSON et peuvent être importées via:
- API Gitea du nouveau serveur
- Scripts d'import personnalisés
- Interface web (manuellement)

### 3. Recréer les organisations
Utiliser les données dans `organizations/` pour recréer la structure.

## Notes importantes
- Les permissions utilisateurs ne sont pas exportées
- Les webhooks doivent être reconfigurés
- Les tokens d'accès doivent être régénérés
- Les clés SSH doivent être réajoutées

## Contact
Pour toute question, contacter l'équipe Virida.
